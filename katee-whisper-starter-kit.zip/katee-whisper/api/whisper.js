export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Only POST allowed' });
  }

  const { fileUrl } = req.body;
  if (!fileUrl) return res.status(400).json({ error: 'Missing audio file URL' });

  const openaiApiKey = process.env.OPENAI_API_KEY;
  const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

  try {
    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`
      },
      body: JSON.stringify({
        file: fileUrl,
        model: 'whisper-1'
      })
    });

    const data = await response.json();
    if (data.error) throw new Error(data.error.message);

    res.status(200).json({ transcript: data.text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
